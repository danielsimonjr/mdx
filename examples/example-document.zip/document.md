# MDX Format Demonstration Document

## Introduction

Welcome to this demonstration of the **MDX (Markdown eXtended Container)** format. This document showcases the capabilities of MDX, including embedded media, interactive content, and collaboration features.

The MDX format combines the simplicity of Markdown with the power of a self-contained document archive. Everything in this document—images, data files, styles—is bundled into a single portable file.

## Core Concepts

### What is MDX?

MDX is an open document format built on three principles:

1. **Radical Openness** — The format is a standard ZIP archive. You can rename any `.mdx` file to `.zip` and extract its contents with any archive utility.

2. **Graceful Degradation** — A basic Markdown renderer shows the core document perfectly. Enhanced viewers unlock additional features.

3. **Web Standards Alignment** — All embedded media types correspond to standard web MIME types.

### Document Structure

An MDX document contains the following structure:

```
document.mdx
├── manifest.json       # Metadata and content inventory
├── document.md         # Primary Markdown content
├── assets/             # All embedded assets
│   ├── images/
│   ├── video/
│   ├── data/
│   └── models/
├── styles/             # CSS stylesheets
├── history/            # Version snapshots
└── annotations/        # Collaborative comments
```

## Embedded Media Examples

### Images

Standard Markdown image syntax works seamlessly:

![MDX Document Structure Diagram](assets/images/structure-diagram.svg)

The image above is embedded in the document and travels with it.

### Data Visualization

MDX can embed structured data:

::data[Quarterly Results]{src="assets/data/quarterly-results.csv" type="chart" chart-type="bar"}

For viewers that don't support charts, the raw CSV data is still accessible.

### 3D Models

Interactive 3D content uses the glTF format:

::model[Component Assembly]{src="assets/models/component.gltf" preview="assets/images/model-preview.svg" interactive}

## Code Examples

Syntax highlighting is supported:

```python
from mdx_format import MDXDocument

# Create a new document
doc = MDXDocument.create("My Document", author="Author Name")
doc.set_content("# Hello World")
doc.add_image("screenshot.png", alt_text="Screenshot")
doc.save("output.mdx")
```

```javascript
// JavaScript example
async function loadMDX(url) {
    const response = await fetch(url);
    const blob = await response.blob();
    return parseMDX(blob);
}
```

## Tables

Standard Markdown tables:

| Feature | Basic Viewer | Enhanced Viewer |
|---------|-------------|-----------------|
| Markdown | ✓ | ✓ |
| Images | ✓ | ✓ |
| Video | Link only | Playback |
| 3D Models | Preview | Interactive |
| Annotations | Hidden | Full support |

## Callouts

:::note{type="info"}
**Information**: MDX supports callout blocks for highlighting important content.
:::

:::note{type="warning"}
**Warning**: Always validate MDX documents before distribution.
:::

:::note{type="tip"}
**Tip**: Use the CLI tools to quickly create and inspect MDX files.
:::

## Mathematical Content

LaTeX-style math is supported:

The quadratic formula is $x = \frac{-b \pm \sqrt{b^2-4ac}}{2a}$.

Block equations:

$$
\int_{-\infty}^{\infty} e^{-x^2} dx = \sqrt{\pi}
$$

## Version History

This document includes version history tracking. Each version snapshot preserves the document state at that point in time.

## Collaboration Features

MDX supports collaborative annotations including comments, highlights, and suggestions. Annotations are stored separately from the main content.

## Conclusion

The MDX format represents an open approach to document packaging that prioritizes openness, portability, and progressive enhancement.

---

*Document Version: 1.0.0*  
*Last Updated: 2026-01-11*
